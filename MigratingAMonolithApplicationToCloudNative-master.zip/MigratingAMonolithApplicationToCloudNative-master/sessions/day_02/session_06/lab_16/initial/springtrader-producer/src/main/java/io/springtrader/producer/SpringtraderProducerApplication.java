package io.springtrader.producer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringtraderProducerApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringtraderProducerApplication.class, args);
    }
}
