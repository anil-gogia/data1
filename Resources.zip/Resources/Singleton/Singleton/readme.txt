Installing the Demo
===================
This demo has been successfully test with Oracle BPEL PM (for Developers) version 10.1.3.2 preview edition on Windows and Linux.

The Singleton.zip should be unzipped to a local directory (for convience it's suggested that you unzip it in the BPEL Samples directory), in order to be deployed your BPEL PM engine. After unzipping, open a Developer Prompt by selecting:

Start -> All Programs -> Oracle -Oracle_Home -> Oracle BPEL Process Manager ->Developer Prompt

From here deploy the demo by typing the following commands:

cd <unzip_directory>\Singleton
ant

To run the demo, first initiate the Singleton process from the BPEL Console. Enure that you specify "Singleton/1.0" as the Singleton Id (note - this should be the default payload). 

Then initiate as many instances of SingletonAccessor as you like. You should see that they all call the same process instance of Singleton.
