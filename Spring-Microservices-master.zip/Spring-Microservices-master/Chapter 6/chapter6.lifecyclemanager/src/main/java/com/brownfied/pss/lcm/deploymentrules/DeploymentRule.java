package com.brownfied.pss.lcm.deploymentrules;

public interface DeploymentRule {
	public boolean execute();
}