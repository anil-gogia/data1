# Spring Microservices
Code repository for [Spring Microservices](https://www.packtpub.com/application-development/spring-microservices?utm_source=github&utm_medium=repository&utm_campaign=9781786466686), published by Packt Publishing

There are no code files for chapters 1, 3, and 10. All hardware requirements are listed in the file named "Hardware and Software requirements". Any other requirements are mentioned in the book wherever necessary.

# Related books
* [Spring Security 3.x Cookbook](https://www.packtpub.com/application-development/spring-security-3x-cookbook?utm_source=github&utm_medium=related&utm_campaign=9781782167525)
* [Learning Spring Boot](https://www.packtpub.com/application-development/learning-spring-boot?utm_source=github&utm_medium=related&utm_campaign=9781784393021)
* [Mastering Microservices with Java](https://www.packtpub.com/application-development/mastering-microservices-java?utm_source=github&utm_medium=related&utm_campaign=9781785285172) - to be published in June 2016


